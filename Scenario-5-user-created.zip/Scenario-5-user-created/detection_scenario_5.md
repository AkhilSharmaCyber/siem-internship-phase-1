
# Detection Use Case: Unauthorized User Creation and Privilege Escalation (T1136 + T1078)

## Scenario Description
An attacker creates a new user account on the system and then escalates its privileges by adding it to the local Administrators group. This technique is often used post-exploitation to maintain persistent access with high privileges.

## Objective
Detect when a new user account is created and subsequently added to a privileged group.

## Tools Used
- *SIEM*: Splunk Enterprise
- *Log Source*: Windows Event Logs (Security)
- *Lab Setup*:
  - Windows VM with Splunk Universal Forwarder installed
  - Splunk Enterprise running on a separate machine
  - Logs monitored: Security.evtx
  - Data forwarded to Splunk over TCP port 9997

---

## Data Source Mapping

| Field Name       | Description / Sample Value        |
|------------------|------------------------------------|
| _time            | 2025-05-25T17:29:16.000+0000        |
| host             | win-victim01                       |
| EventCode        | 4720, 4728, 4732                    |
| Account_Name     | SYSTEM                             |
| Target_Username  | testuser                          |
| Group_Name       | Administrators                     |

---

## 🛡 Detection Logic: New User Creation + Admin Group Addition

This SPL query identifies when a new user is created (Event ID 4720) and is added to a privileged group like Administrators (Event ID 4728 or 4732).

#### 🔍 SPL Query Used:

```spl
index=* EventCode=4720 OR EventCode=4728 OR EventCode=4732
| search EventCode=4720 AND (EventCode=4728 OR EventCode=4732)
| table _time, host, EventCode, Target_Username, Group_Name, Account_Name
| sort -_time
```

---

### ✅ Sample Log Output

| _time              | host         | EventCode | Target_Username | Group_Name     | Account_Name |
|-------------------|--------------|-----------|------------------|----------------|---------------|
| 2025-05-25 17:29  | win-victim01 | 4720      | testuser         | -              | SYSTEM        |
| 2025-05-25 17:29  | win-victim01 | 4732      | testuser         | Administrators | SYSTEM        |

---

### ✅ Detection Status
✅ Working – Tested in local lab with Splunk UF and Security Event Log enabled

---

### 🧠 Analyst Notes / Recommendations

**Detection Category:** Privilege Escalation / Persistence

**Actions:**
- Validate whether the user creation was legitimate.
- Check who executed the command (Account_Name).
- Disable and remove the unauthorized user if not approved.

**Possible False Positives:**
- Legitimate IT staff creating new admin users during maintenance.
