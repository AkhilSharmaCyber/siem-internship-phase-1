
# Brute Force Attack Detection

## Overview  
This detection identifies failed and successful login attempts on a Windows VM host (`hacker`) by analyzing Windows Security Event Logs.

---

## Data Source  
- **Index:** `main`  
- **Sourcetype:** `WinEventLog:Security`  
- **Host:** `hacker` (Windows VM hostname)

---

## Detection Logic

The query searches for two critical Event Codes:  
- **4625** — Failed login attempts  
- **4624** — Successful login attempts  

It returns the event time, EventCode, account name, source IP address, and host for each event, sorted by most recent first.

### SPL Query:
```spl
index=main sourcetype=WinEventLog:Security host=hacker (EventCode=4625 OR EventCode=4624)
| eval Account=Account_Name, src_ip=IpAddress
| table _time, EventCode, Account, src_ip, host
| sort _time desc
```

---

## Explanation  
- This query helps observe all recent login attempts (both failed and successful) on the Windows VM.  
- It allows for manual inspection to identify suspicious login patterns or brute force attempts.

---

## How to Use  
1. Run the query in the Splunk search bar after generating login attempts on the Windows VM.  
2. Review the events to monitor failed and successful login activity.  
3. Optionally, use the timestamps and IPs to correlate suspicious activity.

---

## Notes  
- This query does not automatically detect brute force attacks but provides raw event data for analysis.  
- To automate detection, you can extend the query with stats and filtering to identify repeated failed attempts followed by success.

