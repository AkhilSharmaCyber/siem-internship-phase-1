
# Detection Use Case: Log Tampering via Wevtutil (T1070.001)

## Scenario Description
An attacker, after gaining elevated privileges on a Windows machine, may attempt to cover their tracks by clearing the Windows Security event logs. This is typically done using tools like `wevtutil.exe` or PowerShell commands such as `Clear-EventLog`. Detecting this activity is critical, as it often follows sensitive malicious actions like privilege escalation, persistence, or lateral movement.

## Objective
Detect any attempts to clear security logs using either native Windows tools (`wevtutil`, `Clear-EventLog`) or other utilities, as well as monitor when Security log clearing occurs.

## Tools Used
- *SIEM*: Splunk Enterprise  
- *Log Source*: Windows Security Logs, Sysmon  
- *Lab Setup*:
  - Windows VM with Splunk Universal Forwarder
  - Splunk Enterprise on separate host
  - Logs monitored:
    - `WinEventLog:Security`
    - `XmlWinEventLog:Microsoft-Windows-Sysmon/Operational`
  - Data forwarded to Splunk over TCP 9997

---

## Data Source Mapping

| Field Name     | Description / Sample Value                             |
|----------------|---------------------------------------------------------|
| _time          | 2025-05-25T08:47:32.000+0000                            |
| Account_Name   | SYSTEM or Admin account performing the action          |
| Computer       | Hostname of the Windows VM (e.g., WIN-VM01)            |
| Image          | Full path to process, e.g., `C:\Windows\System32\wevtutil.exe` |
| CommandLine    | Command that was executed (if captured by Sysmon)      |
| EventCode      | 1102 (Security Log Cleared), 1 (Process Creation)      |
| LogName        | Security / Microsoft-Windows-Sysmon/Operational        |

---

## 🛡 Detection Logic: Detect Log Tampering (Clear Logs)

This SPL query identifies events related to security log tampering — either by detecting the `Security` log being cleared or by catching the execution of suspicious log-clearing commands.

### 🔍 SPL Query 1 – Security Log Cleared

```spl
index=* sourcetype=WinEventLog:Security EventCode=1102
| table _time, Account_Name, ComputerName, Message
```

### 🔍 SPL Query 2 – Execution of Wevtutil or PowerShell

```spl
index=* sourcetype=XmlWinEventLog:Microsoft-Windows-Sysmon/Operational EventCode=1
| search Image="*wevtutil.exe" OR Image="*powershell.exe"
| table _time, Computer, User, Image, CommandLine
```

---

## ✅ Detection Status:
✅ Working – Successfully tested by running `wevtutil cl Security` on Windows VM and verified detection in Splunk logs.

---

## Analyst Notes / Recommendations

**Detection Category:** Defense Evasion → Log Tampering

**Actions:**
- Immediately isolate the machine
- Investigate all prior suspicious logon or privilege escalation attempts
- Correlate with other artifacts like file access or scheduled tasks

**Possible False Positives:**
- Rare legitimate use by system administrators (should be logged/documented)
- Automated maintenance jobs or group policy scripts (verify in environment)
