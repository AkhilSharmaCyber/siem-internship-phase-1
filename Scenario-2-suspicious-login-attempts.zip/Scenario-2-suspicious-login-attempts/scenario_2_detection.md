
## Detection Use Case: Suspicious Off-Hours Admin Logins

## Scenario Description
An attacker gains access to a privileged account and attempts to log in during off-business hours (before 9 AM or after 7 PM) to evade detection and gain persistence.

## Objective
Detect successful logins by admin accounts occurring outside normal working hours (before 09:00 or after 19:00).

## Tools Used
- *SIEM*: Splunk Enterprise
- *Log Source*: Windows Event Logs (Security)
- *Lab Setup*:
  - Windows VM with Splunk Universal Forwarder installed
  - Splunk Enterprise running on analysis system
  - Logs monitored: Security (EventCode 4624)
  - Data forwarded to Splunk over TCP port 9997

---

## Data Source Mapping

| Field Name       | Description / Sample Value        |
|------------------|------------------------------------|
| _time            | 2025-05-25T08:05:34.000            |
| Account_Name     | redadmin                           |
| Logon_Type       | 2 or 10 (interactive or RDP)       |
| host             | hacker                             |
| Security_ID      | S-1-5-21-XXXXX                     |

---

## 🛡 Detection Logic: Admin Logins Outside Business Hours

This SPL query identifies successful logins by privileged accounts like `redadmin` that occur outside business hours (9 AM to 7 PM).

#### 🔍 SPL Query Used:

```spl
index=* sourcetype=WinEventLog:Security EventCode=4624 
| eval hour=strftime(_time, "%H") 
| where (hour<9 OR hour>19) AND Account_Name="redadmin"
| table _time, Account_Name, Logon_Type, host, user, Security_ID
```

---

#### ✅ Detection Status:
✅ Working – Simulated using a test admin account (`redadmin`) logged in on 05/25/2025 at 08:05:34 AM from host `hacker`.

---

### Analyst Notes / Recommendations

**Detection Category:** Anomaly-based login monitoring

**Actions:**
- Verify if the login was scheduled or expected.
- Correlate with any file or process activity post-login.
- Trigger endpoint investigation or isolate system if necessary.

**Possible False Positives:**
- Legitimate IT/DevOps/admin activity during maintenance windows
- Manual system reboots or patching during off-hours
