
# Scenario 3: Lateral Movement via RDP (T1021.001)

## 🔍 Detection Name:
Suspicious Lateral Movement via RDP from Non-Standard IP

---

## 🎯 Objective:
Detect lateral movement attempts from a non-standard internal IP using Remote Desktop Protocol (RDP), identified through multiple failed login attempts followed by a successful one.

---

## 🧪 Attack Simulation Summary:

- **Attacker Machine**: Kali Linux
- **Victim Machine**: Windows VM (RDP enabled)
- **Attack Method**:
  1. Used `ncrack` to simulate brute-force RDP login attempts.
  2. Final successful login using `xfreerdp` from the same Kali IP.
  3. Targeted the `redadmin` user account on the Windows machine.
- **Tools Used**: `ncrack`, `xfreerdp`, Splunk Enterprise

---

## 📥 Logs Collected:
- **Source**: Windows Security Logs via Universal Forwarder
- **Sourcetype**: `WinEventLog:Security`
- **Event Codes**:
  - `4625`: Failed login
  - `4624`: Successful login
- **Logon Type**: `10` (RDP)

---

## 📈 Detection Query (SPL):

```spl
index=main sourcetype=WinEventLog:Security (EventCode=4624 OR EventCode=4625) Logon_Type=10 earliest=-30m@m latest=now
| eval src_ip=coalesce(IpAddress, Source_Network_Address)
| eval Account=coalesce(Account_Name, TargetUserName)
| sort _time asc
| eventstats count(eval(EventCode=4625)) as failed_attempts by src_ip, Account
| where EventCode=4624 AND failed_attempts > 0
| table _time, src_ip, Account, failed_attempts
```

---

## 🔎 Detection Logic:
- Filters RDP login events (Logon Type 10).
- Counts failed login attempts (4625) by source IP and account.
- Checks if a successful login (4624) follows failed attempts.
- Ensures activity is within a 30-minute window.

---

## ✅ Detection Result:

| Account  | src_ip         | Failed Attempts | Successful Logins | First Attempt Time | Last Attempt Time |
|----------|----------------|-----------------|--------------------|--------------------|-------------------|
| redadmin | 192.168.64.134 | 6               | 1                  | 2025-05-25 11:03:11           | 2025-05-25 11:03:39          |

---

## 🛠️ Recommendations:
- Alert on this behavior to SOC.
- Investigate source IP and timeline.
- Block the offending IP if attack is confirmed.
- Enforce account lockout policies and MFA for privileged users.

---

## 🖼️ Screenshot Checklist:
- [x] Event Viewer showing 4625 and 4624 for Logon Type 10.
- [x] Splunk results with src_ip, Account, and timestamps.
- [x] Matching attack timeframe using ncrack and xfreerdp from Kali.
